function [y] = f_lagrange(X,Y,x) % modified version: f_lagrange(X,Y,x,n)
sum = 0;
for j = 1 : 3 % assuming n = 3, if not change 3 to n
    product = 1;
    for k = 1 : 3 % change 3 to n for modified version
        if k ~= j
            product = product * ((x - X(k))/(X(j) - X(k)));
        end
    end
sum = sum + Y(j) * product;
end
y = sum;
end